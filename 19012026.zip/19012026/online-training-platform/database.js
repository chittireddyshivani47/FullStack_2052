const { Sequelize } = require("sequelize");

const sequelize = new Sequelize("training_db", "root", "shivani", {
  host: "localhost",
  dialect: "mysql"
});

module.exports = sequelize;
