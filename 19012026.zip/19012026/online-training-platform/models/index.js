const Course = require("./Course");
const Enrollment = require("./Enrollment");

Course.belongsToMany(Enrollment, { through: "CourseEnrollments" });
Enrollment.belongsToMany(Course, { through: "CourseEnrollments" });

module.exports = { Course, Enrollment };
