
const express = require("express");
const sequelize = require("./database");
const courseRoutes = require("./routes/courseRoutes");

const app = express();

app.use(express.json());
app.use("/api/courses", courseRoutes);

app.get("/", (req, res) => {
  res.send("Online Training Platform API is running 🚀");
});


sequelize.sync({ alter: true })
  .then(() => {
    console.log("Database connected & tables created");
    app.listen(3000, () => {
      console.log("Server running at http://localhost:3000");
    });
  })
  .catch(err => console.log(err));
