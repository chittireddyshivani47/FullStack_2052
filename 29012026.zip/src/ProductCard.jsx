import React, { useState } from "react";

function ProductCard(props) {
  const [count, setCount] = useState(0);

  return (
    <div style={{ border: "1px solid black", margin: "10px", padding: "10px" }}>
      <h3>{props.name}</h3>
      <p>Price: ₹{props.price}</p>

      <button onClick={() => setCount(count + 1)}>
        Add to Cart
      </button>

      <p>Items Added: {count}</p>
    </div>
  );
}

export default ProductCard;
