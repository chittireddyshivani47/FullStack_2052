import React from 'react';
import './Stats.css';

const Stats = ({ stats }) => {
  return (
    <div className="stats-container">
      <div className="stat-card">
        <div className="stat-icon">📊</div>
        <div className="stat-info">
          <div className="stat-value">{stats.totalEvents}</div>
          <div className="stat-label">Total Events</div>
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-icon">🎯</div>
        <div className="stat-info">
          <div className="stat-value">{stats.upcomingEvents}</div>
          <div className="stat-label">Upcoming</div>
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-icon">✅</div>
        <div className="stat-info">
          <div className="stat-value">{stats.completedEvents}</div>
          <div className="stat-label">Completed</div>
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-icon">👥</div>
        <div className="stat-info">
          <div className="stat-value">{stats.totalParticipants}</div>
          <div className="stat-label">Total Participants</div>
        </div>
      </div>
    </div>
  );
};

export default Stats;
