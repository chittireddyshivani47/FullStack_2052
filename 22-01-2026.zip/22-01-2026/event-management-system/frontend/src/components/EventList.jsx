import React from 'react';
import './EventList.css';

const EventList = ({ events, onSelectEvent, onEdit, onDelete }) => {
  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusColor = (status) => {
    const colors = {
      'Upcoming': '#3498db',
      'Ongoing': '#2ecc71',
      'Completed': '#95a5a6',
      'Cancelled': '#e74c3c'
    };
    return colors[status] || '#95a5a6';
  };

  if (events.length === 0) {
    return (
      <div className="empty-state">
        <p>📭 No events found</p>
        <p>Create your first event to get started!</p>
      </div>
    );
  }

  return (
    <div className="event-list">
      <h2>All Events ({events.length})</h2>
      <div className="events-grid">
        {events.map(event => (
          <div key={event._id} className="event-card">
            <div 
              className="status-badge" 
              style={{ backgroundColor: getStatusColor(event.status) }}
            >
              {event.status}
            </div>
            
            <h3 onClick={() => onSelectEvent(event)}>{event.title}</h3>
            
            <div className="event-info">
              <div className="info-item">
                <span className="icon">📅</span>
                <span>{formatDate(event.date)}</span>
              </div>
              
              <div className="info-item">
                <span className="icon">📍</span>
                <span>{event.location}</span>
              </div>
              
              <div className="info-item">
                <span className="icon">🏷️</span>
                <span>{event.category}</span>
              </div>
              
              <div className="info-item">
                <span className="icon">👥</span>
                <span>{event.participants?.length || 0} participants</span>
              </div>
            </div>

            {event.description && (
              <p className="description">{event.description.substring(0, 100)}...</p>
            )}

            <div className="card-actions">
              <button 
                className="btn-view"
                onClick={() => onSelectEvent(event)}
              >
                View Details
              </button>
              <button 
                className="btn-edit"
                onClick={() => onEdit(event)}
              >
                Edit
              </button>
              <button 
                className="btn-delete"
                onClick={() => onDelete(event._id)}
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EventList;
